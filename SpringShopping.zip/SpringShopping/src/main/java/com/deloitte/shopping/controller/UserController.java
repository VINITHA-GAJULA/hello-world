package com.deloitte.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.shopping.model.Register;
import com.deloitte.shopping.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService Userv;

	@GetMapping("/login")
	public String loginPage() {
		return "login";// view or page
	}

	@PostMapping("/login")
	public String HomePage(@RequestParam String email, @RequestParam String password, ModelMap model) {
		int i = Userv.getUserByEmail(email, password);
		if (i > 0) {
			model.put("email", email);
			return "home";
		} else {
			model.put("errorMsg", "Invalid Credentials. Please register");
			return "login";
		}
	}

	@GetMapping("/register")
	public String registerPage() {
		return "register";
	}

	@PostMapping("/register")
	public String registerUser(@ModelAttribute("reg") Register reg, ModelMap model) {
		Userv.createNewUser(reg);
		return "login";

	}

}