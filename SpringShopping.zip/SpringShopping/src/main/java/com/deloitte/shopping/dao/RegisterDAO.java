package com.deloitte.shopping.dao;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.deloitte.shopping.model.Register;

public interface RegisterDAO extends JpaRepositoryImplementation<Register, Long> {

}
